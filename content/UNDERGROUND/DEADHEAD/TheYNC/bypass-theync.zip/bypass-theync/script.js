function onReady() {
  /////////////////
  //// BYPASS ////
  ///////////////

  // THEYNC.COM ////
  $(".input").focus();
  $(".input[type='text']").on("click", function () {
    $(this).select();
  });

  function bypass() {
    if ($("#lnk").val().length === 0) {
      alert("Enter image URL!");
    } else {
      let text = $("#lnk").val();
      text = text.replace("/thumbs/", "/videos/");
      text = text.replace(/thumbs/g, "media");
      text = text.split(".mp4/")[0];

      console.log(text);

      $("#output").attr("href", text + ".mp4");
      $("#srcVid").attr("src", text + ".mp4");

      $("video").show();
      $("video").focus();
      $(".dwn-btn").show();

      $(".desc").hide();
    }
  }

  $(".input").keypress(function (e) {
    if (e.which == 13) {
      bypass();
      return false;
    }
  });

  $("#bypassBtn").on("click", bypass);
  // END THEYNC.COM
} ////END
if (document.readyState !== "loading") {
  onReady(); // Or setTimeout(onReady, 0); if you want it consistently async
} else {
  document.addEventListener("DOMContentLoaded", onReady);
}
